# 🚀 GUÍA DE INSTALACIÓN - TandaSegura

## 📦 PASO 1: Subir a GitHub

### Opción A: Usando GitHub Web (Más fácil)

1. **Crear cuenta en GitHub** (si no tienes)
   - Ve a https://github.com
   - Click en "Sign up"
   - Sigue los pasos de registro

2. **Crear nuevo repositorio**
   - Ve a https://github.com/new
   - **Repository name:** `tandasegura`
   - **Description:** `Plataforma de ahorro colaborativo PWA`
   - Marca ✅ "Public"
   - Marca ✅ "Add a README file"
   - Click "Create repository"

3. **Subir archivos**
   - En tu repositorio, click "Add file" > "Upload files"
   - Arrastra TODOS los archivos y carpetas de este ZIP
   - Escribe en "Commit message": "Initial commit - TandaSegura PWA"
   - Click "Commit changes"

### Opción B: Usando GitHub Desktop

1. **Descargar GitHub Desktop**
   - https://desktop.github.com/
   - Instala e inicia sesión

2. **Crear repositorio**
   - File > New Repository
   - Name: `tandasegura`
   - Local Path: elige una carpeta
   - Click "Create Repository"

3. **Copiar archivos**
   - Click "Show in Explorer"
   - Copia TODOS los archivos del ZIP en esa carpeta

4. **Publicar**
   - Vuelve a GitHub Desktop
   - Escribe "Initial commit"
   - Click "Commit to main"
   - Click "Publish repository"

---

## 🌐 PASO 2: Activar GitHub Pages (Hacer visible tu app)

1. **En tu repositorio de GitHub**, ve a:
   - **Settings** (arriba a la derecha)

2. **Busca "Pages"** en el menú izquierdo

3. **Configurar:**
   - Source: selecciona **"GitHub Actions"**

4. **Crear workflow de despliegue:**
   - Ve a la pestaña "Actions"
   - Click "New workflow"
   - Busca "Static HTML" o "Deploy to GitHub Pages"
   - O crea uno nuevo con este contenido:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          
      - name: Install dependencies
        run: npm install
        
      - name: Build
        run: npm run build
        
      - name: Deploy to GitHub Pages
        uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./dist
```

5. **Espera 2-3 minutos** y tu app estará en:
   ```
   https://TU-USUARIO.github.io/tandasegura/
   ```

---

## 🎨 PASO 3: Personalizar (Opcional)

### Cambiar colores
Edita `tailwind.config.js`:
```javascript
primary: {
  500: '#10b981',  // Cambia este color
}
```

### Agregar iconos PWA
- Coloca tus iconos en `public/icons/`
- Tamaños: 192x192px y 512x512px
- Formato: PNG
- Lee el archivo `ICONOS.txt` para más detalles

### Cambiar nombre
Edita `public/manifest.json`:
```json
{
  "name": "Tu Nombre Aquí",
  "short_name": "Nombre Corto"
}
```

---

## 💻 PASO 4: Probar Localmente (Opcional)

Si quieres probar en tu computadora antes de subir:

1. **Instalar Node.js**
   - Descarga de: https://nodejs.org
   - Instala la versión LTS (recomendada)

2. **Abrir terminal en la carpeta del proyecto**
   - Windows: Shift + Click derecho > "Abrir PowerShell aquí"
   - Mac: Click derecho > "New Terminal at Folder"

3. **Instalar dependencias**
   ```bash
   npm install
   ```

4. **Iniciar servidor de desarrollo**
   ```bash
   npm run dev
   ```

5. **Abrir navegador**
   - Ve a: http://localhost:5173
   - ¡Tu app estará funcionando!

---

## 📱 PASO 5: Instalar como App (Después de desplegar)

### En Android/Chrome:
1. Abre tu app en Chrome
2. Toca los 3 puntos (⋮)
3. "Agregar a pantalla de inicio"
4. ¡Listo! Ahora funciona como app nativa

### En iOS/Safari:
1. Abre tu app en Safari
2. Toca el botón de compartir (⬆️)
3. "Añadir a pantalla de inicio"
4. ¡Listo!

### En Desktop:
1. Abre tu app en Chrome
2. Busca el ícono de instalación (➕) en la barra de direcciones
3. Click "Instalar"

---

## 🆘 PROBLEMAS COMUNES

### "La página no se muestra"
- Espera 5 minutos después de activar GitHub Pages
- Verifica que el repositorio sea público
- Revisa la pestaña "Actions" para ver si hay errores

### "Los estilos no se ven"
- Asegúrate de haber subido TODAS las carpetas
- Verifica que `vite.config.js` tenga: `base: '/tandasegura/'`

### "No puedo crear el repositorio"
- Verifica tu conexión a internet
- Confirma tu email en GitHub
- Intenta con GitHub Desktop

---

## 🎯 PRÓXIMOS PASOS

Una vez que tu app esté funcionando:

1. ✅ Personaliza colores y nombre
2. ✅ Agrega tus propios iconos
3. ✅ Invita a amigos a probarla
4. ✅ Comparte el link de tu app
5. ✅ ¡Empieza a gestionar tus tandas!

---

## 📞 SOPORTE

¿Necesitas ayuda?
- Lee el README.md para más información
- Revisa los archivos ICONOS.txt para guías de iconos
- Contacta al desarrollador si tienes dudas

---

**¡Tu plataforma de ahorro colaborativo está lista para usar!** 🎉

Desarrollado con ❤️ para facilitar el ahorro en comunidad.
