# 🎯 TandaSegura PWA

Plataforma de ahorro colaborativo digital - Gestiona tus tandas de forma fácil y segura.

## 🚀 Características

- ✅ Progressive Web App (PWA) - Funciona sin conexión
- 💰 Gestión de múltiples tandas
- 👥 Administración de participantes
- 📊 Dashboard con estadísticas
- 💳 Control de pagos y turnos
- 🔔 Notificaciones automáticas
- 📱 Diseño responsive (móvil y escritorio)

## 📦 Instalación

### Opción 1: Desarrollo local

```bash
# Instalar dependencias
npm install

# Iniciar servidor de desarrollo
npm run dev

# Abrir en el navegador: http://localhost:5173
```

### Opción 2: Build para producción

```bash
# Generar archivos optimizados
npm run build

# Vista previa del build
npm run preview
```

## 🌐 Despliegue en GitHub Pages

1. Sube el proyecto a tu repositorio de GitHub
2. Ve a **Settings** > **Pages**
3. Selecciona **Branch: main** > **/root**
4. Click en **Save**
5. Tu app estará disponible en: `https://tu-usuario.github.io/tandasegura/`

## 🛠️ Tecnologías

- React 18
- Vite
- Tailwind CSS
- Lucide React (iconos)
- PWA (Service Workers)

## 📱 Instalar como App

Una vez desplegada, puedes instalar TandaSegura en tu dispositivo:

- **Android/Chrome:** Click en "Agregar a pantalla de inicio"
- **iOS/Safari:** Compartir > "Añadir a pantalla de inicio"
- **Desktop:** Icono de instalación en la barra de direcciones

## 🎨 Personalización

Edita los colores en `tailwind.config.js`:

```javascript
colors: {
  primary: {
    500: '#10b981', // Color principal
  }
}
```

## 📄 Licencia

MIT - Uso libre

## 🤝 Soporte

¿Preguntas? Abre un issue en GitHub o contacta al desarrollador.

---

**Hecho con ❤️ para la comunidad de ahorro colaborativo**
