import React from 'react'
import TandaDigitalApp from './components/TandaDigitalApp'

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <TandaDigitalApp />
    </div>
  )
}

export default App
