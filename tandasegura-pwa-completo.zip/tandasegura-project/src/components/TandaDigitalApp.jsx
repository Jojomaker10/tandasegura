import React, { useState, useEffect } from 'react';
import { Users, DollarSign, Calendar, TrendingUp, Plus, Edit2, Trash2, Check, X, AlertCircle } from 'lucide-react';

const TandaDigitalApp = () => {
  const [tandas, setTandas] = useState([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [selectedTanda, setSelectedTanda] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');

  // Cargar datos del localStorage
  useEffect(() => {
    const savedTandas = localStorage.getItem('tandas');
    if (savedTandas) {
      setTandas(JSON.parse(savedTandas));
    }
  }, []);

  // Guardar datos en localStorage
  useEffect(() => {
    localStorage.setItem('tandas', JSON.stringify(tandas));
  }, [tandas]);

  // Formulario para crear tanda
  const CreateTandaForm = () => {
    const [formData, setFormData] = useState({
      nombre: '',
      monto: '',
      participantes: '',
      frecuencia: 'semanal',
      fechaInicio: ''
    });

    const handleSubmit = (e) => {
      e.preventDefault();
      const numParticipantes = parseInt(formData.participantes);
      
      const nuevaTanda = {
        id: Date.now(),
        ...formData,
        monto: parseFloat(formData.monto),
        participantes: Array.from({ length: numParticipantes }, (_, i) => ({
          id: i + 1,
          nombre: `Participante ${i + 1}`,
          pagado: false,
          turno: i + 1
        })),
        turnoActual: 1,
        estado: 'activa',
        fechaCreacion: new Date().toISOString()
      };

      setTandas([...tandas, nuevaTanda]);
      setShowCreateForm(false);
      setFormData({
        nombre: '',
        monto: '',
        participantes: '',
        frecuencia: 'semanal',
        fechaInicio: ''
      });
    };

    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-lg p-6 max-w-md w-full">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-bold text-gray-800">Nueva Tanda</h3>
            <button onClick={() => setShowCreateForm(false)} className="text-gray-500 hover:text-gray-700">
              <X size={24} />
            </button>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Nombre de la Tanda
              </label>
              <input
                type="text"
                required
                value={formData.nombre}
                onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="Ej: Tanda Oficina 2024"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Monto por Participante
              </label>
              <input
                type="number"
                required
                min="1"
                value={formData.monto}
                onChange={(e) => setFormData({...formData, monto: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="$1000"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Número de Participantes
              </label>
              <input
                type="number"
                required
                min="2"
                max="50"
                value={formData.participantes}
                onChange={(e) => setFormData({...formData, participantes: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                placeholder="10"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Frecuencia de Pago
              </label>
              <select
                value={formData.frecuencia}
                onChange={(e) => setFormData({...formData, frecuencia: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              >
                <option value="semanal">Semanal</option>
                <option value="quincenal">Quincenal</option>
                <option value="mensual">Mensual</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Fecha de Inicio
              </label>
              <input
                type="date"
                required
                value={formData.fechaInicio}
                onChange={(e) => setFormData({...formData, fechaInicio: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-primary-500 focus:border-transparent"
              />
            </div>

            <div className="flex gap-2 pt-4">
              <button
                type="button"
                onClick={() => setShowCreateForm(false)}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="flex-1 px-4 py-2 bg-primary-500 text-white rounded-md hover:bg-primary-600"
              >
                Crear Tanda
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  // Dashboard principal
  const Dashboard = () => {
    const tandasActivas = tandas.filter(t => t.estado === 'activa').length;
    const totalParticipantes = tandas.reduce((acc, t) => acc + t.participantes.length, 0);
    const montoTotal = tandas.reduce((acc, t) => acc + (t.monto * t.participantes.length), 0);

    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Tandas Activas</p>
                <p className="text-3xl font-bold text-gray-800">{tandasActivas}</p>
              </div>
              <div className="bg-primary-100 p-3 rounded-full">
                <TrendingUp className="text-primary-600" size={24} />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Participantes</p>
                <p className="text-3xl font-bold text-gray-800">{totalParticipantes}</p>
              </div>
              <div className="bg-blue-100 p-3 rounded-full">
                <Users className="text-blue-600" size={24} />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Monto Total</p>
                <p className="text-3xl font-bold text-gray-800">${montoTotal.toLocaleString()}</p>
              </div>
              <div className="bg-green-100 p-3 rounded-full">
                <DollarSign className="text-green-600" size={24} />
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-bold text-gray-800">Mis Tandas</h2>
          </div>
          <div className="p-6">
            {tandas.length === 0 ? (
              <div className="text-center py-12">
                <AlertCircle className="mx-auto text-gray-400 mb-4" size={48} />
                <p className="text-gray-600 mb-4">No tienes tandas creadas</p>
                <button
                  onClick={() => setShowCreateForm(true)}
                  className="btn-primary inline-flex items-center gap-2"
                >
                  <Plus size={20} />
                  Crear Primera Tanda
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {tandas.map(tanda => (
                  <div
                    key={tanda.id}
                    className="border border-gray-200 rounded-lg p-4 hover:shadow-lg transition-shadow cursor-pointer"
                    onClick={() => {
                      setSelectedTanda(tanda);
                      setActiveTab('detalle');
                    }}
                  >
                    <div className="flex justify-between items-start mb-3">
                      <h3 className="font-semibold text-gray-800">{tanda.nombre}</h3>
                      <span className={`px-2 py-1 text-xs rounded-full ${
                        tanda.estado === 'activa' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {tanda.estado}
                      </span>
                    </div>
                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <DollarSign size={16} />
                        <span>${tanda.monto.toLocaleString()} por persona</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users size={16} />
                        <span>{tanda.participantes.length} participantes</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar size={16} />
                        <span>Turno {tanda.turnoActual} de {tanda.participantes.length}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  // Vista de detalle de tanda
  const TandaDetalle = () => {
    if (!selectedTanda) return null;

    const marcarPago = (participanteId) => {
      const tandasActualizadas = tandas.map(t => {
        if (t.id === selectedTanda.id) {
          return {
            ...t,
            participantes: t.participantes.map(p =>
              p.id === participanteId ? { ...p, pagado: !p.pagado } : p
            )
          };
        }
        return t;
      });
      setTandas(tandasActualizadas);
      setSelectedTanda(tandasActualizadas.find(t => t.id === selectedTanda.id));
    };

    const siguienteTurno = () => {
      const tandasActualizadas = tandas.map(t => {
        if (t.id === selectedTanda.id) {
          return {
            ...t,
            turnoActual: Math.min(t.turnoActual + 1, t.participantes.length),
            participantes: t.participantes.map(p => ({ ...p, pagado: false }))
          };
        }
        return t;
      });
      setTandas(tandasActualizadas);
      setSelectedTanda(tandasActualizadas.find(t => t.id === selectedTanda.id));
    };

    const eliminarTanda = () => {
      if (confirm('¿Estás seguro de eliminar esta tanda?')) {
        setTandas(tandas.filter(t => t.id !== selectedTanda.id));
        setSelectedTanda(null);
        setActiveTab('dashboard');
      }
    };

    const pagosRealizados = selectedTanda.participantes.filter(p => p.pagado).length;
    const progreso = (pagosRealizados / selectedTanda.participantes.length) * 100;

    return (
      <div className="space-y-6">
        <div className="bg-white rounded-lg shadow p-6">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-800">{selectedTanda.nombre}</h2>
              <p className="text-gray-600">Turno {selectedTanda.turnoActual} de {selectedTanda.participantes.length}</p>
            </div>
            <button
              onClick={eliminarTanda}
              className="text-red-600 hover:text-red-800"
            >
              <Trash2 size={20} />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Monto por Persona</p>
              <p className="text-2xl font-bold text-gray-800">${selectedTanda.monto.toLocaleString()}</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Frecuencia</p>
              <p className="text-2xl font-bold text-gray-800 capitalize">{selectedTanda.frecuencia}</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm text-gray-600">Progreso de Pagos</p>
              <p className="text-2xl font-bold text-gray-800">{pagosRealizados}/{selectedTanda.participantes.length}</p>
            </div>
          </div>

          <div className="mb-6">
            <div className="flex justify-between text-sm text-gray-600 mb-2">
              <span>Progreso del Turno Actual</span>
              <span>{Math.round(progreso)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className="bg-primary-500 h-3 rounded-full transition-all duration-300"
                style={{ width: `${progreso}%` }}
              />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow">
          <div className="p-6 border-b border-gray-200 flex justify-between items-center">
            <h3 className="text-xl font-bold text-gray-800">Participantes</h3>
            {pagosRealizados === selectedTanda.participantes.length && (
              <button
                onClick={siguienteTurno}
                className="btn-primary inline-flex items-center gap-2"
              >
                Siguiente Turno
              </button>
            )}
          </div>
          <div className="p-6">
            <div className="space-y-3">
              {selectedTanda.participantes.map(participante => (
                <div
                  key={participante.id}
                  className={`flex items-center justify-between p-4 rounded-lg border-2 ${
                    participante.turno === selectedTanda.turnoActual
                      ? 'border-primary-500 bg-primary-50'
                      : 'border-gray-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${
                      participante.turno === selectedTanda.turnoActual
                        ? 'bg-primary-500 text-white'
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {participante.turno}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-800">{participante.nombre}</p>
                      <p className="text-sm text-gray-600">
                        {participante.turno === selectedTanda.turnoActual ? 'Turno actual' : `Turno ${participante.turno}`}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => marcarPago(participante.id)}
                    className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                      participante.pagado
                        ? 'bg-green-500 text-white hover:bg-green-600'
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    {participante.pagado ? (
                      <span className="flex items-center gap-2">
                        <Check size={16} />
                        Pagado
                      </span>
                    ) : (
                      'Marcar pago'
                    )}
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-primary-500 text-white shadow-lg">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold">TandaSegura</h1>
              <p className="text-primary-100">Gestiona tus tandas de forma fácil y segura</p>
            </div>
            {activeTab === 'dashboard' && tandas.length > 0 && (
              <button
                onClick={() => setShowCreateForm(true)}
                className="bg-white text-primary-600 px-4 py-2 rounded-lg font-semibold hover:bg-primary-50 inline-flex items-center gap-2"
              >
                <Plus size={20} />
                Nueva Tanda
              </button>
            )}
            {activeTab === 'detalle' && (
              <button
                onClick={() => {
                  setActiveTab('dashboard');
                  setSelectedTanda(null);
                }}
                className="bg-white text-primary-600 px-4 py-2 rounded-lg font-semibold hover:bg-primary-50"
              >
                Volver al Dashboard
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'detalle' && <TandaDetalle />}
      </main>

      {/* Modal Create Form */}
      {showCreateForm && <CreateTandaForm />}
    </div>
  );
};

export default TandaDigitalApp;
